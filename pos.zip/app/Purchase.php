<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    public function supplier()
    {
    	return $this->belongsTo('App\Supplier');
    }

    public function category()
    {
    	return $this->belongsTo('App\Category');
    }

    public function unit()
    {
    	return $this->belongsTo('App\Unit');
    }

    public function product()
    {
    	return $this->belongsTo('App\Product');
    }

    public function createdUser()
    {
        return $this->hasOne('App\User','id','created_by');
    }

    // public function user()
    // {
    //     return $this->hasOne('App\User','id','created_by');
    // }

    public function approvedUser()
    {
        return $this->hasOne('App\User','id','updated_by');
    }
}
