<?php

namespace App\Http\Controllers;

use App\Category;
use App\Product;
use App\Purchase;
use App\Supplier;
use App\Unit;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PurchaseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $data['suppliers'] = Supplier::all();
        $data['categories'] = Category::all();
        $data['units'] = Unit::all();
        $data['products'] = Product::all();
        $data['purchases'] = Purchase::orderBy('date','desc')->orderBy('id','desc')->get();

        // Generate Purchase No
        $purchase_data = Purchase::orderBy('id','desc')->first();
        if($purchase_data == null){
            $firstReg = '0';
            $data['purchase_no'] = $firstReg+1;
        }else{
            $purchase_data = Purchase::orderBy('id','desc')->first()->purchase_no;
            $data['purchase_no'] = $purchase_data+1;
        }
        // Generate Today Date
        $data['date'] = date('Y-m-d');

        return view('backend.purchase.index',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if($request->product_id == null){
            Toastr::error('You do not select any product','No Product');
            return redirect()->back();
        }else{
            $count_category = count($request->category_id);
            for ($i=0; $i <$count_category; $i++) { 
                $purchase               = new Purchase;
                $purchase->date         = date('Y-m-d', strtotime($request->date[$i]));
                $purchase->purchase_no  = $request->purchase_no[$i];
                $purchase->supplier_id  = $request->supplier_id[$i];
                $purchase->category_id  = $request->category_id[$i];
                $purchase->product_id   = $request->product_id[$i];
                $purchase->buying_qty   = $request->buying_qty[$i];
                $purchase->unit_price   = $request->unit_price[$i];
                $purchase->buying_price = $request->buying_price[$i];
                $purchase->description  = $request->description[$i];
                $purchase->status       = '0';
                $purchase->created_by   = Auth::user()->id;
                $purchase->save();
            }
        }
        Toastr::success('Product Purchase Successfully','Purchase');
        return redirect()->route('purchase.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Purchase  $purchase
     * @return \Illuminate\Http\Response
     */
    public function show(Purchase $purchase)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Purchase  $purchase
     * @return \Illuminate\Http\Response
     */
    public function edit(Purchase $purchase)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Purchase  $purchase
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Purchase $purchase)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Purchase  $purchase
     * @return \Illuminate\Http\Response
     */
    public function destroy(Purchase $purchase)
    {
        $purchase->delete();
        Toastr::success('Product Purchase Deleted','Deleted');
        return redirect()->route('purchase.index');
    }

    public function getCategory(Request $request)
    {
        $supplier_id = $request->supplier_id;
        $categories = Product::with(['category'])
                            ->select('category_id')
                            ->where('supplier_id', $supplier_id)
                            ->groupBy('category_id')
                            ->get();
        return response()->json($categories);
    }

    public function getProduct(Request $request)
    {
        $category_id = $request->category_id;
        $products = Product::where('category_id',$category_id)->get();

        return response()->json($products);
    }

    public function approve($id)
    {
        $data['purchase'] = Purchase::findOrFail($id);
        return view('backend.purchase.purchase',$data);
        
    }

    public function approveStore($id)
    {
        $purchase = Purchase::findOrFail($id);
        $product = Product::where('id', $purchase->product_id)->first();
        $purchase_qty = ((float)($purchase->buying_qty))+((float)($product->quantity));

        $product->quantity = $purchase_qty;
        if($product->save()){
            DB::table('purchases')->where('id',$id)->update([
                'status' => 1,
                'updated_by' => Auth::user()->id,
            ]);
        }
        Toastr::success('Product Purchase Approved','Approve');
        return redirect()->route('purchase.index');
        
    }

    public function purchaseDownload($id)
    {
        $data['purchase'] = Purchase::findOrFail($id);
        return view('backend.purchase.purchase-download',$data);
    }
}
