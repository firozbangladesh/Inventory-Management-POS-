<?php

namespace App\Http\Controllers;

use App\Supplier;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SupplierController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['suppliers'] = Supplier::orderBy('name')->get();
        return view('backend.supplier.index',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name'      => 'required',
            'mobile'    => 'required'
        ]);

        $supplier               = new Supplier();
        $supplier->name         = $request->name;
        $supplier->mobile       = $request->mobile;
        $supplier->email        = $request->email;
        $supplier->mpo_name     = $request->mpo_name;
        $supplier->address      = $request->address;
        $supplier->status       = '1';
        $supplier->created_by   = Auth::user()->id;
        $supplier->save();

        Toastr::success('Create','Supplier Creaded Successfully');
        return redirect()->route('supplier.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Supplier  $supplier
     * @return \Illuminate\Http\Response
     */
    public function show(Supplier $supplier)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Supplier  $supplier
     * @return \Illuminate\Http\Response
     */
    public function edit(Supplier $supplier)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Supplier  $supplier
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Supplier $supplier)
    {
        $this->validate($request,[
            'name'      => 'required',
            'mobile'    => 'required'
        ]);

        $supplier->name         = $request->name;
        $supplier->mobile       = $request->mobile;
        $supplier->email        = $request->email;
        $supplier->mpo_name     = $request->mpo_name;
        $supplier->address      = $request->address;
        $supplier->status       = '1';
        $supplier->updated_by   = Auth::user()->id;
        $supplier->save();

        Toastr::success('Update','Supplier Updated Successfully');
        return redirect()->route('supplier.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Supplier  $supplier
     * @return \Illuminate\Http\Response
     */
    public function destroy(Supplier $supplier)
    {
        $supplier->delete();

        Toastr::success('Delete','Supplier Deleted Successfully');
        return redirect()->route('supplier.index');
    }
}
