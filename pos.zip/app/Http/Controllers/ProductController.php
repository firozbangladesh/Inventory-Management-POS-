<?php

namespace App\Http\Controllers;

use App\Category;
use App\Product;
use App\Supplier;
use App\Unit;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['products'] = Product::all();
        $data['suppliers'] = Supplier::all();
        $data['categories'] = Category::all();
        $data['units'] = Unit::all();

        return view('backend.product.index',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name' => 'required',
            'supplier_id' => 'required',
            'category_id' => 'required',
            'unit_id' => 'required',
        ]);

        $product = new Product;
        $product->name = $request->name;
        $product->supplier_id = $request->supplier_id;
        $product->category_id = $request->category_id;
        $product->unit_id = $request->unit_id;
        $product->status = '1';
        $product->created_by = Auth::user()->id;
        $product->save();

        Toastr::success('Product Created Successfully','Created');
        return redirect()->route('product.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        $this->validate($request,[
            'name' => 'required',
            'supplier_id' => 'required',
            'category_id' => 'required',
            'unit_id' => 'required',
        ]);

        $product->name = $request->name;
        $product->supplier_id = $request->supplier_id;
        $product->category_id = $request->category_id;
        $product->unit_id = $request->unit_id;
        $product->status = '1';
        $product->updated_by = Auth::user()->id;
        $product->save();

        Toastr::success('Product Updated Successfully','Updated');
        return redirect()->route('product.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        $product->delete();
        Toastr::success('Product Deleted Successfully','Deleted');
        return redirect()->route('product.index');
    }

    public function productStock()
    {
        // dd('ok');
        $data['products'] = Product::orderBy('name','asc')->get();
        $data['date'] = date('Y-m-d');
        return view('backend.product.stock',$data);
    }

    public function productStockSupplier(Request $request)
    {
        // dd('ok');
        $supplier_id = $request->supplier_id;
        $data['products'] = Product::orderBy('category_id','asc')->where('supplier_id',$supplier_id)->get();
        $data['date'] = date('Y-m-d');
        $data['supplier'] = Supplier::where('id',$supplier_id)->first();
        return view('backend.product.stock-supplier',$data);
    }

    public function productStockProduct(Request $request)
    {
        // dd('ok');
        $product_id = $request->product_id;
        $data['products'] = Product::orderBy('name','asc')->where('id',$product_id)->get();
        $data['date'] = date('Y-m-d');
        $data['product'] = Product::where('id',$product_id)->first();
        return view('backend.product.stock-product',$data);
    }
}
