<?php

namespace App\Http\Controllers;

use App\Customer;
use Brian2694\Toastr\Facades\Toastr;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['customers'] = Customer::all();
        return view('backend.customer.index',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name' => 'required',
        ]);

        $image = $request->file('image');
        if(isset($image)){
            $imageName = uniqid().'.'.$image->getClientOriginalExtension();
            if(!file_exists('image/customer')){
                mkdir('image/customer', 0777, true);
            }
            $image->move('image/customer/', $imageName);
        }else{
            $imageName = 'dafault.png';
        }

        $customer = new Customer();
        $customer->name = $request->name;
        $customer->father_name = $request->father_name;
        $customer->mobile = $request->mobile;
        $customer->email = $request->email;
        $customer->address = $request->address;
        $customer->status = '1';
        $customer->created_by = Auth::user()->id;
        $customer->image = $imageName;
        $customer->save();

        Toastr::success('Customer Created Successfully','Created');
        return redirect()->route('customer.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function show(Customer $customer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function edit(Customer $customer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Customer $customer)
    {
        $this->validate($request,[
            'name' => 'required',
        ]);

        $image = $request->file('image');
        if(isset($image)){
            if(file_exists('image/customer/'.$customer->image)){
                unlink('image/customer/'.$customer->image);
            }
            $imageName = uniqid().'.'.$image->getClientOriginalExtension();
            if(!file_exists('image/customer')){
                mkdir('image/customer', 0777, true);
            }
            $image->move('image/customer/', $imageName);
        }else{
            $imageName = $customer->image;
        }

        $customer->name = $request->name;
        $customer->father_name = $request->father_name;
        $customer->mobile = $request->mobile;
        $customer->email = $request->email;
        $customer->address = $request->address;
        $customer->status = '1';
        $customer->updated_by = Auth::user()->id;
        $customer->image = $imageName;
        $customer->save();

        Toastr::success('Customer Updated Successfully','Updated');
        return redirect()->route('customer.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Customer $customer)
    {
        $customer->delete();
        Toastr::success('Customer Deleted Successfully','Deleted');
        return redirect()->route('customer.index');
    }
}
