<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    public function payment()
    {
    	return $this->hasOne('App\Payment');
    }

    public function invoice_details()
    {
    	return $this->hasMany('App\InvoiceDetail');
    }

    public function createdUser()
    {
    	return $this->hasOne('App\User','id','created_by');
    }

    public function ApprovedUser()
    {
        return $this->hasOne('App\User','id','approved_by');
    }

}
